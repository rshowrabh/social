<aside class="col-lg-1 col-sm-2 pr-0">

    <div class="post-left post-right d-none d-sm-block position-fixed ml-auto">
        <div id="mySidebar1" class="sidebar-right border-left">
            <div class="fixed-part">
                <div title="Close" id="myBtn1" class="neew-right">
                    <span>Community Affairs</span>
                    <a href="javascript:void(0)" class="right-menu-closebtn">
                        <img src="images/cross.png">
                    </a>
                </div>
                <div class="about-list">
                    <div class="panel-title">
                        <a class="d-flex align-items-center" href="#">
                            <img src="images/one.png" class="mr-1">
                            <div>
                                <p class="mb-1 panel-text">Mike John reacted to your photo</p>
                                <small class="mb-0"> March 10 at 9:05PM </small>
                            </div>
                        </a>
                    </div>
                    <div class="panel-title">
                        <a class="d-flex align-items-center" href="#">
                            <img src="images/two.png" class="mr-1">
                            <div>
                                <p class="mb-1 panel-text">Mike John reacted to your photo</p>
                                <small class="mb-0"> March 10 at 9:05PM </small>
                            </div>
                        </a>
                    </div>
                    <div class="panel-title">
                        <a class="d-flex align-items-center" href="#">
                            <img src="images/three.png" class="mr-1">
                            <div>
                                <p class="mb-1 panel-text">Mike John reacted to your photo</p>
                                <small class="mb-0"> March 10 at 9:05PM </small>
                            </div>
                        </a>
                    </div>
                    <div class="panel-title">
                        <a class="d-flex align-items-center" href="#">
                            <img src="images/four.png" class="mr-1">
                            <div>
                                <p class="mb-1 panel-text">Mike John reacted to your photo</p>
                                <small class="mb-0"> March 10 at 9:05PM </small>
                            </div>
                        </a>
                    </div>
                    <h4 class="contact m-0 py-2">Contacts</h4>
                    <div class="panel-title">
                        <a class="d-flex align-items-center active" href="#">
                            <img src="images/five.png" class="mr-1">
                            <p class="mb-0 panel-text"><b>Katie Daviscourt</b></p>
                        </a>
                    </div>
                    <div class="panel-title">
                        <a class="d-flex align-items-center active" href="#">
                            <img src="images/six.png" class="mr-1">
                            <p class="mb-0 panel-text"><b>Katie Daviscourt</b></p>
                        </a>
                    </div>
                    <div class="panel-title">
                        <a class="d-flex align-items-center active" href="#">
                            <img src="images/seven.png" class="mr-1">
                            <p class="mb-0 panel-text"><b>Katie Daviscourt</b></p>
                        </a>
                    </div>
                    <div class="panel-title">
                        <a class="d-flex align-items-center active" href="#">
                            <img src="images/eight.png" class="mr-1">
                            <p class="mb-0 panel-text"><b>Katie Daviscourt</b></p>
                        </a>
                    </div>
                    <div class="panel-title">
                        <a class="d-flex align-items-center active" href="#">
                            <img src="images/nine.png" class="mr-1">
                            <p class="mb-0 panel-text"><b>Katie Daviscourt</b></p>
                        </a>
                    </div>
                    <div class="panel-title">
                        <a class="d-flex align-items-center active" href="#">
                            <img src="images/ten.png" class="mr-1">
                            <p class="mb-0 panel-text"><b>Katie Daviscourt</b></p>
                        </a>
                    </div>
                    <div class="panel-title">
                        <a class="d-flex align-items-center active" href="#">
                            <img src="images/11.png" class="mr-1">
                            <p class="mb-0 panel-text"><b>Katie Daviscourt</b></p>
                        </a>
                    </div>
                    <div class="panel-title">
                        <a class="d-flex align-items-center active" href="#">
                            <img src="images/12.png" class="mr-1">
                            <p class="mb-0 panel-text"><b>Katie Daviscourt</b></p>
                        </a>
                    </div>
                    <div class="panel-title">
                        <a class="d-flex align-items-center active" href="#">
                            <img src="images/13.png" class="mr-1">
                            <p class="mb-0 panel-text"><b>Katie Daviscourt</b></p>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="right-menu h-100" title="Open">
            <ul id='showChatUserList' class="right-menu-to-hide two mb-0">

                <li>
                    <a class="img-to-hide" href="#">
                        <img src="images/back.png" alt="back" class="toggoler-img">
                    </a>
                </li>



            </ul>
        </div>
    </div>
    <div class="contact-list-toggoler rounded-circle position-fixed d-flex align-items-center justify-content-center">
        <a href="#!"><i class="fas fa-plus-circle"></i> <small id='messageCount' class='text-danger position-absolute'></small>    </a>
    </div>

    <div class="contact-list-container position-fixed border w-100 overflow-hidden">
      
          <div id='plusIconAppend' class="body overflow-auto">
            
        </div>
    </div>
    <!-- Messeger Area -->
    <div class="messenger-container">
        
    </div>
</aside>